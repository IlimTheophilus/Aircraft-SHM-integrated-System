
# ashmi_live_with_snapshot.py
import streamlit as st
import cv2
import numpy as np
from PIL import Image
import io
import time

st.set_page_config(page_title="ASHMI Live + Snapshot", layout="wide")
st.title("ASHMI — Live Real-time Defect Detector + Snapshot Analyzer")

st.markdown("""
Live webcam stream with continuous defect candidate detection and a **Take snapshot** button.
- Live stream: continuous detection and bounding boxes.
- Snapshot: capture any live frame, then tweak parameters and re-analyze the snapshot instantly.
**Only uses:** streamlit, opencv-python, numpy, pillow.
""")

# ------------------------
# Sidebar: global params (applies to live)
# ------------------------
with st.sidebar:
    st.header("Live stream settings")
    cam_index = st.number_input(
        "Camera index", min_value=0, max_value=5, value=0, step=1)
    resize_width = st.slider(
        "Resize width (px) — lower = faster", 320, 1280, 640, step=32)
    clahe_clip_live = st.slider("CLAHE clip limit (live)", 1.0, 8.0, 2.0, 0.1)
    blur_k_live = st.selectbox("Gaussian blur kernel (odd) (live)", [
                               1, 3, 5, 7, 9], index=1)
    canny_low_live = st.slider("Canny low (live)", 1, 255, 50)
    canny_high_live = st.slider("Canny high (live)", 1, 500, 150)
    morph_k_live = st.selectbox(
        "Morph kernel size (live)", [3, 5, 7, 9], index=0)
    morph_iter_live = st.slider("Morph iterations (live)", 0, 3, 1)
    min_area_live = st.number_input(
        "Min contour area (live px)", min_value=1, max_value=100000, value=80, step=1)
    max_area_live = st.number_input(
        "Max contour area (live px)", min_value=100, max_value=10000000, value=10000, step=100)
    aspect_crack_live = st.slider(
        "Aspect ratio for 'crack' (w/h) (live)", 1.5, 50.0, 6.0, 0.5)
    delam_area_live = st.number_input(
        "Delamination area threshold (live px)", min_value=10, max_value=100000, value=1500, step=10)
    show_edge_map_live = st.checkbox("Show edge map (live debug)", value=False)
    show_labels_live = st.checkbox("Show labels on boxes (live)", value=True)
    show_fps_live = st.checkbox("Show FPS (live)", value=True)

    st.markdown("---")
    if st.button("Stop live stream"):
        st.session_state.running = False
        st.experimental_rerun()
    st.caption(
        "Click 'Stop live stream' to close webcam. Otherwise it runs continuously.")

# ------------------------
# Session state initialization
# ------------------------
if "cap" not in st.session_state:
    st.session_state.cap = None
if "running" not in st.session_state:
    st.session_state.running = True              # auto-start live
if "last_frame_time" not in st.session_state:
    st.session_state.last_frame_time = time.time()

# Snapshot state
if "snapshot_bytes" not in st.session_state:
    st.session_state.snapshot_bytes = None
if "take_snapshot" not in st.session_state:
    st.session_state.take_snapshot = False

# ------------------------
# Layout: left = live, right = snapshot & controls
# ------------------------
live_col, snap_col = st.columns((2, 1))

# Live placeholder
live_placeholder = live_col.empty()
if show_edge_map_live:
    live_edge_placeholder = live_col.empty()
else:
    live_edge_placeholder = None
live_info = live_col.empty()

# Snapshot UI elements (right column)
with snap_col:
    st.subheader("Snapshot panel")
    st.markdown(
        "Take a snapshot from the live stream, then tweak parameters below to re-analyze the snapshot instantly.")
    if st.button("Take snapshot from live"):
        # set flag — captured in live loop below
        st.session_state.take_snapshot = True
    if st.button("Clear snapshot"):
        st.session_state.snapshot_bytes = None

    st.markdown("---")
    st.markdown("Snapshot analysis settings (independent - adjust freely)")

    # Snapshot-specific params (so you can tune separately from live)
    clahe_clip_snap = st.slider(
        "CLAHE clip limit (snapshot)", 1.0, 8.0, 2.0, 0.1, key="clahe_snap")
    blur_k_snap = st.selectbox("Gaussian blur kernel (odd) (snapshot)", [
                               1, 3, 5, 7, 9], index=1, key="blur_snap")
    canny_low_snap = st.slider(
        "Canny low (snapshot)", 1, 255, 50, key="canny_low_snap")
    canny_high_snap = st.slider(
        "Canny high (snapshot)", 1, 500, 150, key="canny_high_snap")
    morph_k_snap = st.selectbox("Morph kernel size (snapshot)", [
                                3, 5, 7, 9], index=0, key="morph_k_snap")
    morph_iter_snap = st.slider(
        "Morph iterations (snapshot)", 0, 3, 1, key="morph_iter_snap")
    min_area_snap = st.number_input("Min contour area (snapshot px)",
                                    min_value=1, max_value=100000, value=80, step=1, key="min_area_snap")
    max_area_snap = st.number_input("Max contour area (snapshot px)", min_value=100,
                                    max_value=10000000, value=10000, step=100, key="max_area_snap")
    aspect_crack_snap = st.slider(
        "Aspect ratio for 'crack' (w/h) (snapshot)", 1.5, 50.0, 6.0, 0.5, key="aspect_snap")
    delam_area_snap = st.number_input("Delamination area threshold (snapshot px)",
                                      min_value=10, max_value=100000, value=1500, step=10, key="delam_snap")
    show_labels_snap = st.checkbox(
        "Show labels on boxes (snapshot)", value=True, key="show_labels_snap")
    download_name = st.text_input(
        "Snapshot download name", value="ashmi_snapshot.jpg", key="download_name")

# ------------------------
# Helper functions
# ------------------------


def open_camera(idx):
    try:
        cap = cv2.VideoCapture(int(idx))
        # warm up a few frames
        for _ in range(3):
            if not cap.isOpened():
                break
            cap.read()
        return cap
    except Exception:
        return None


def release_camera():
    try:
        if st.session_state.cap is not None:
            try:
                st.session_state.cap.release()
            except Exception:
                pass
    finally:
        st.session_state.cap = None


def resize_keep_aspect(frame, width):
    h, w = frame.shape[:2]
    if w <= width:
        return frame
    scale = width / float(w)
    return cv2.resize(frame, (int(w*scale), int(h*scale)), interpolation=cv2.INTER_AREA)


def preprocess_gray(bgr, clahe_clip, blur_k):
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=float(clahe_clip), tileGridSize=(8, 8))
    gray = clahe.apply(gray)
    if blur_k > 1:
        gray = cv2.GaussianBlur(gray, (blur_k, blur_k), 0)
    return gray


def detect_candidates(gray, canny_low, canny_high, morph_k, morph_iter, min_area, max_area):
    edges = cv2.Canny(gray, int(canny_low), int(canny_high))
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (morph_k, morph_k))
    closed = cv2.morphologyEx(edges, cv2.MORPH_CLOSE,
                              kernel, iterations=int(morph_iter))
    contours, _ = cv2.findContours(
        closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    candidates = []
    h, w = gray.shape
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area < min_area or area > max_area:
            continue
        x, y, ww, hh = cv2.boundingRect(cnt)
        candidates.append({"box": (x, y, x+ww, y+hh),
                          "area": area, "w": ww, "h": hh})
    return closed, candidates


def heuristic_label(c, aspect_thresh, delam_area_thresh):
    aspect = (c["w"] / (c["h"] + 1e-8))
    area = c["area"]
    if aspect > aspect_thresh:
        return "crack"
    if area > delam_area_thresh:
        return "delamination"
    return "candidate"


def bgr_to_jpeg_bytes(bgr):
    _, buf = cv2.imencode(".jpg", bgr)
    return buf.tobytes()


def jpeg_bytes_to_pil(bts):
    return Image.open(io.BytesIO(bts)).convert("RGB")


# ------------------------
# Ensure camera is open
# ------------------------
if st.session_state.running and st.session_state.cap is None:
    st.session_state.cap = open_camera(cam_index)
    if st.session_state.cap is None or not st.session_state.cap.isOpened():
        st.error("Unable to open webcam. Confirm camera index and permissions.")
        st.session_state.running = False

# ------------------------
# Live loop
# ------------------------
if st.session_state.running and st.session_state.cap is not None:
    cap = st.session_state.cap
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                live_info.error("Failed to read frame from webcam.")
                break

            frame = resize_keep_aspect(frame, resize_width)

            # Live preprocess + detect
            gray_live = preprocess_gray(frame, clahe_clip_live, blur_k_live)
            edge_live, cand_live = detect_candidates(
                gray_live, canny_low_live, canny_high_live, morph_k_live, morph_iter_live, int(min_area_live), int(max_area_live))

            vis = frame.copy()
            # annotate live candidates
            for c in cand_live:
                x0, y0, x1, y1 = c["box"]
                cv2.rectangle(vis, (x0, y0), (x1, y1), (0, 0, 255), 2)
                if show_labels_live:
                    lab = heuristic_label(
                        c, aspect_crack_live, delam_area_live)
                    cv2.putText(vis, lab, (x0, max(
                        12, y0-5)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)

            # FPS
            if show_fps_live:
                now = time.time()
                dt = now - st.session_state.last_frame_time if st.session_state.last_frame_time else 0
                fps = 1.0 / dt if dt > 0 else 0.0
                st.session_state.last_frame_time = now
                cv2.putText(vis, f"FPS: {fps:.1f}", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

            # Display live frame
            live_placeholder.image(cv2.cvtColor(vis, cv2.COLOR_BGR2RGB))

            # Show live edge map optionally
            if show_edge_map_live and live_edge_placeholder is not None:
                live_edge_placeholder.image(edge_live, caption="Live edge map")

            # If snapshot flag is set, save the current processed frame (annotated vis) as bytes
            if st.session_state.get("take_snapshot", False):
                try:
                    st.session_state.snapshot_bytes = bgr_to_jpeg_bytes(
                        vis)  # store annotated frame JPEG bytes
                    st.session_state.take_snapshot = False
                    # give user quick feedback
                    live_info.success(
                        "Snapshot taken and saved to Snapshot panel.")
                except Exception as e:
                    live_info.error(f"Failed to save snapshot: {e}")
                    st.session_state.take_snapshot = False

            # Allow slight sleep for CPU yield
            time.sleep(0.02)

            # Check stop flag
            if not st.session_state.running:
                break

    except Exception as e:
        live_info.error(f"Runtime error in live loop: {e}")
    finally:
        release_camera()
        live_info.info("Live stream stopped.")
else:
    release_camera()
    live_placeholder.markdown(
        "Live stream is stopped. Refresh page to auto-start.")

# ------------------------
# Snapshot display + interactive analysis
# ------------------------
with snap_col:
    st.markdown("---")
    if st.session_state.snapshot_bytes is None:
        st.info(
            "No snapshot taken yet. Click 'Take snapshot from live' to capture current live frame.")
    else:
        # show original snapshot (annotated at capture but we will re-process using snapshot params)
        try:
            pil_snapshot = jpeg_bytes_to_pil(st.session_state.snapshot_bytes)
            st.image(
                pil_snapshot, caption="Captured snapshot (as captured)", use_column_width=True)
            # convert to BGR for processing
            bgr_snap = cv2.cvtColor(np.array(pil_snapshot), cv2.COLOR_RGB2BGR)

            # Re-process snapshot using snapshot params (runs automatically when you move any widget)
            gray_snap = preprocess_gray(bgr_snap, clahe_clip_snap, blur_k_snap)
            edge_snap, cand_snap = detect_candidates(
                gray_snap, canny_low_snap, canny_high_snap, morph_k_snap, morph_iter_snap, int(min_area_snap), int(max_area_snap))
            # annotate snapshot
            annotated_snap = bgr_snap.copy()
            for c in cand_snap:
                x0, y0, x1, y1 = c["box"]
                cv2.rectangle(annotated_snap, (x0, y0),
                              (x1, y1), (0, 0, 255), 2)
                if show_labels_snap:
                    lab = heuristic_label(
                        c, aspect_crack_snap, delam_area_snap)
                    cv2.putText(annotated_snap, lab, (x0, max(
                        12, y0-5)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)

            st.markdown(
                "**Annotated snapshot (live-updates as you change snapshot sliders)**")
            st.image(cv2.cvtColor(annotated_snap, cv2.COLOR_BGR2RGB),
                     use_column_width=True)

            st.markdown("Snapshot detections:")
            if cand_snap:
                for i, c in enumerate(cand_snap[:12]):
                    st.write(
                        f"- #{i+1}: label={heuristic_label(c, aspect_crack_snap, delam_area_snap)}, area={int(c['area'])} px, box={c['box']}")
            else:
                st.write("No candidates found with current snapshot parameters.")

            # Edge map small preview and download annotated
            st.download_button("Download annotated snapshot", data=bgr_to_jpeg_bytes(
                annotated_snap), file_name=download_name, mime="image/jpeg")
            if st.checkbox("Show snapshot edge map (debug)"):
                st.image(edge_snap, caption="Snapshot edge map",
                         use_column_width=True)

        except Exception as e:
            st.error(f"Failed to process snapshot: {e}")

# Footer tips
st.markdown("---")
st.markdown("""
**Usage tips**
- Keep the live `Resize width` lower to increase FPS. Use higher for more detail.
- To capture a frame of interest, click **Take snapshot from live** — then tune snapshot sliders on the right for fine analysis.
- Snapshot parameters are independent so you can tune more aggressively without slowing the live stream.
""")
